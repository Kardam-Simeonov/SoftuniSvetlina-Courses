﻿namespace HouseRentingSystem.Models.Agents
{
    public class AgentViewModel
    {
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
    }
}
