﻿namespace HouseRentingSystem.Models.Houses
{
    public class HouseCategoryViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
