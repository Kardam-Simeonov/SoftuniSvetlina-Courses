﻿namespace ForumDemo.Models
{
    public class PostFormModel
    {
        public string Content { get; set; }
    }
}
