function autoCycle(){
    $('.carousel').carousel('cycle');
}

function next(){
    $('.carousel').carousel('next');
}

function prev(){
    $('.carousel').carousel('prev');
}