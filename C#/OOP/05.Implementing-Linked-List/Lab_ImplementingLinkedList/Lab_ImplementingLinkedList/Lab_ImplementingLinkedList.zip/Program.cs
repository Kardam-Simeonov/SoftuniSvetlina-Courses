﻿using System;

namespace Lab_ImplementingLinkedList
{
    public class StartUp
    {
        static void Main(string[] args)
        {
        }
    }
}
