﻿using System;

namespace ImplementArrayList
{
    public class Startup
    {
        static void Main(string[] args)
        {
            CustomArrayList custom = new CustomArrayList();
        }
    }
}
