﻿using System;

namespace CircularQueue
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}
