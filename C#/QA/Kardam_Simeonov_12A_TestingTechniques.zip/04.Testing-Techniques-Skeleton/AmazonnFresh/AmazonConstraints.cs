﻿namespace AmazonnFresh
{
    public class AmazonConstraints
    {
        public const int NewCustomerDiscount = 10;

        public const int CouponDiscount = 30;

        public const int AmazonBrandedDiscount = 1;
    }
}
