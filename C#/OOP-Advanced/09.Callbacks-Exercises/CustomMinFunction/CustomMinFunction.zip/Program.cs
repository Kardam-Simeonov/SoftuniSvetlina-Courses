﻿using System;
using System.Runtime.Intrinsics.X86;

namespace CustomMinFunction
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // a simple program that reads from the console a set of integers and prints back on the console the smallest number from the collection. Use Func&lt; T, T & gt;.

            string[] input = Console.ReadLine().Split();

            Func<string[], int> min = x =>
            {
                int minNumber = int.MaxValue;
                foreach (string number in x)
                {
                    int currentNumber = int.Parse(number);
                    if (currentNumber < minNumber)
                    {
                        minNumber = currentNumber;
                    }
                }
                return minNumber;
            };

            Console.WriteLine(min(input));
        }
    }
}
