﻿using System;

namespace ImplementLinkedList
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}
