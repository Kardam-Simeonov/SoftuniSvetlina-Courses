﻿using System;

namespace ImplementCustomStack
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}
