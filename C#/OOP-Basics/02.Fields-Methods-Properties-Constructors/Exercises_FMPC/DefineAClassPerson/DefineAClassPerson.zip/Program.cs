﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            //Person person1 = new Person("Pesho", 20);
            //Person person2 = new Person("Gosho", 18);
            //Person person3 = new Person("Stamat", 43);
        }
    }
}
