﻿using System;

namespace ImplementCircularQueue
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}
