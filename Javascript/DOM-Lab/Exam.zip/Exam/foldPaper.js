function foldPaper(n){
    console.log(`${0.0005 * Math.pow(2, n)}m`);
}
