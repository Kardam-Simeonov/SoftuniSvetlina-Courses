function areaOfCountry(name, area){
    console.log(`${name} is ${((area / 148940000) * 100).toFixed(2)}% of the total world's landmass`);
}